from django.shortcuts import render
from django.views.generic.base import TemplateView
from django.views.generic.edit import CreateView,UpdateView,DeleteView
from django.views.generic.list import ListView
from django.urls import reverse_lazy
from booksapp.models import BookDetails
from .forms import *


# Create your views here.

class BooksCreateView(CreateView):
    model = BookDetails
    form_class = BooksForm
    template_name = 'booksapp/bookform.html'
    success_url = reverse_lazy('BookList')

class BooksListView(ListView):
    model = BookDetails
    template_name = 'booksapp/booklist.html'
    context_object_name = 'booklist'
    
    
class BookDeleteView(DeleteView):
    model = BookDetails
    success_url = reverse_lazy('BookList')

class BookUpdateView(UpdateView):
    model = BookDetails
    template_name = 'booksapp/bookform.html'
    form_class = BooksForm
    success_url = reverse_lazy('BookList')
    
    def get_context_data(self, **kwargs):
        data = super().get_context_data(**kwargs)
        data['booklist'] = BookDetails.objects.all()
        return data 
    
    def AboutUs(req):
     return render(req,'booksapp/AboutUs.html',data)     