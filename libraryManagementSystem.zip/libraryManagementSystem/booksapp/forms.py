from django import forms
from .models import BookDetails
from django.forms import widgets
class BooksForm(forms.ModelForm):
    class Meta:
        model = BookDetails
        fields = '__all__'
        widgets = {
            'book_Title' : forms.TextInput(attrs={'placeholder':'Enter Name'}),
            'book_Author' : forms.TextInput(attrs={'placeholder':'Enter Author'}),
            'book_Category' : forms.TextInput(attrs={'placeholder':'Enter Category'}),
            'book_Edition' : forms.NumberInput(attrs={'placeholder':'Enter Edition No.'}),
            'book_Price' : forms.NumberInput(attrs={'placeholder':'Enter Price'}),
        }