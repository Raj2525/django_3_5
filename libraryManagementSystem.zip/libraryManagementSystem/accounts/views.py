from django.shortcuts import render
from.models import MyUser
from django.views.generic.edit import *
from django.contrib.auth.views import LoginView
from accounts.forms import MyAdminCreationForm
from django.urls import reverse_lazy

# Create your views here.

def home(req):
    return render(req,'accounts/home.html')


class SignInView(LoginView):
    model = MyUser
    template_name = 'accounts/signin.html'

class SignUpView(CreateView):
    model = MyUser
    form_class = MyAdminCreationForm
    template_name = 'accounts/signup.html'
    success_url = reverse_lazy('Home')
      

    
    
    
     