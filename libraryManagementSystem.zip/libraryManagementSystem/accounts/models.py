from django.db import models
from django.contrib.auth.models import AbstractBaseUser,BaseUserManager

# Create your models here.
class MyUserManager(BaseUserManager):
    
    def _create_user(self,Email,password,**extrafield):
        if not Email:
            raise ValueError('Email Id is complsory')
        user = self.model(Email=Email,password=password,**extrafield)
        user.set_password(password)
        user.save(using=self._db)
        return user
    
    
    def create_user(self,Email,password,**extrafield):
        extrafield.setdefault('is_superuser',False)
        user = self._create_user(Email,password,**extrafield)
        return user
    
    def create_superuser(self,Email,password,**extrafield):
        extrafield.setdefault('is_superuser',True)
        user = self._create_user(Email,password,**extrafield)
        return user

class MyUser(AbstractBaseUser):
    Firts_Name = models.CharField(max_length=30)
    Last_Name = models.CharField(max_length=30)
    Email = models.CharField(unique=True,max_length=40)
    is_superuser = models.BooleanField(default=False)
 
    
    def __str__(self) -> str:
         return f"{self.Firts_Name}"
    
    objects = MyUserManager()
    USERNAME_FIELD = 'Email'
    REQUIRED_FIELDS =[]