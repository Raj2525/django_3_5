from django.db import models

# Create your models here.

class BookDetails(models.Model):
    book_Id = models.BigAutoField(primary_key=True)
    book_Title = models.CharField(max_length=30)
    book_Author = models.CharField(max_length=30)
    book_Category = models.CharField(max_length=30)
    book_Edition = models.IntegerField()
    book_Price = models.FloatField()
