from django.urls import path
from accounts.views import *


urlpatterns = [
    
    path('',home),
    path('signin',SignInView.as_view(),name='signin'),
    path('signup',SignUpView.as_view(),name='signup'),
    
    
]