from django import forms
from django.contrib.auth.forms import UserCreationForm
from.models import MyUser
   
class MyAdminCreationForm(UserCreationForm):
    
    class Meta:
        model = MyUser
        fields = '__all__'
        fields = ('Firts_Name','Last_Name','Email','password1','password2')        