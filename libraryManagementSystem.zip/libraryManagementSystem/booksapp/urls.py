from django.urls import path
from django.views.generic.base import TemplateView
from .views import *

urlpatterns = [
    path('',TemplateView.as_view(template_name='booksapp/home.html'),name='Home'),
    path('addbook',BooksCreateView.as_view(),name='AddBooks'),
    path('booklist',BooksListView.as_view(),name= 'BookList'),
    path('deletebook/<pk>',BookDeleteView.as_view(),name='DeleteBooks'),
    path('updatebook/<pk>',BookUpdateView.as_view(),name='UpdateBooks'),
    path('about',TemplateView.as_view(template_name='booksapp/AboutUs.html'),name='AboutUs')
]